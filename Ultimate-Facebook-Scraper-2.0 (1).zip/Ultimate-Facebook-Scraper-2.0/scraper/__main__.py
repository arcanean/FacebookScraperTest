from .scraper import scraper

scraper()
